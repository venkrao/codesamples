package com.nasa.marsrover.roverinput;

/**
 * Reads the navigation instructions, which at the moment are one among L R M
 *  
 */

import com.nasa.marsrover.Rover;
import com.nasa.marsrover.explore.InstructionAction;

public class ReadRoverNavigationInstructions implements ReadInput, ValidateInput {

 /**
  * Reads instruction string, and updates the rover object. 
  */
 @Override
 public void readAndInitialize(Rover rover, String instructionExplorePlateau) {
  if (instructionExplorePlateau.isEmpty()) {
   throw new IllegalArgumentException("Empty string received in place of instructions "
       + "to explore plateau!");
  }
  if (this.validate(instructionExplorePlateau)) {
   rover.setInstructions(instructionExplorePlateau);
  }
 }

 /**
  * Validate if the given instruction is known, and valid.
  */
 
 @Override
 public boolean validate(String instructionString) {
  InstructionAction instructions = new InstructionAction();
  String[] instructionsArray = instructionString.trim().split("");

  for (int i = 0; i < instructionsArray.length; i++) {
   if (!instructions.getInstructionActions().containsKey(instructionsArray[i])) {
    throw new IllegalArgumentException("Invalid instruction character: " + instructionsArray[i]);
   }
  }
  return true;
 }

}