package com.nasa.marsrover.explore;

import com.nasa.marsrover.Rover;

/**
 * Interface that is implemented by those
 * classes that execute certain instruction
 * whose execution-feasibility must be checked
 * before actually executing them.
 * 
 * @author Venkatakrishna Rao K S
 *
 */
public interface InstructionExecutionFeasibility {
 public boolean isFeasibleAction(Rover rover);
}