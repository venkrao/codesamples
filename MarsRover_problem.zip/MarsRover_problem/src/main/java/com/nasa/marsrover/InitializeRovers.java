package com.nasa.marsrover;

/**
 * Initializes the rovers based on the input provided.
 * 
 */
import java.util.ArrayList;
import java.util.Scanner;

import com.nasa.marsrover.roverinput.RoverInputSequence;

public class InitializeRovers {

  /**
   * 
   * @param The scanner object from which input is read.
   * @return ArrayList containing input to the given rovers.
   */
 public ArrayList < Rover > readRoversInput(Scanner sc) {
  ArrayList < Rover > rovers = new ArrayList < Rover > ();

  String input = null;

  /**
   *
   * Plateau is read only once. Hence, it is outside the loop,
   * the loop.
   * The loop is in there to adhere to "Open/closed principle"
   * there by making extension of this class possible, without any changes to the class,
   * to the logic down there, except when the requirements themselves change.
   * 
   * Couldn't find a better way to read plateau boundary coordinates, without making
   * the whole thing complicated.
   */

  // Read plateau upper right coordinates.
  input = sc.nextLine();
  if (input.isEmpty()) {
   sc.close();
   throw new IllegalArgumentException("Plateau coordinates cannot be left empty.");
  }

  Coordinates upperRightCoordinates = new Coordinates();
  upperRightCoordinates.setCoordinatesFromString(input);

  if (upperRightCoordinates.areCoordinatesNegative()) {
   throw new IllegalArgumentException("Plateau upper right coordinates cannot be negative.");
  }

  Plateau plateau = new Plateau(upperRightCoordinates);

  // Input is read in sequence, which as per the requirements *known* now
  // is in a predefined order.

  // Should the order change, it is enough to just change the InputDataSequence.class
  // and no changes are necessary here.

  // Total number of inputs for a given rover.
  RoverInputSequence inputDataSequence = new RoverInputSequence();

  // Tracks how many *types* of inputs are to be read for a rover.
  Integer i = 0;

  Rover rover = null;

  do {
   if (i == 0) {
    // Initialize rover whose input is being read.
    rover = new Rover();
    rover.setPlateau(plateau);
    // Plateau to explore is is common for all rovers!
   }

   if (i == inputDataSequence.getTotalInputDataItems()) {
    // We are done reading input. so, add this rover to the list of rovers.
    // and instantiate the next rover object.
    rovers.add(rover);
    i = 0;
    rover = new Rover();
    rover.setPlateau(plateau);
   }

   i = i + 1;

   input = sc.nextLine();

   if (input.isEmpty()) {
    // If input is empty, then, we check if we already read input for at leat 
    // one rover. If we did, we assume user is done providing input.
    if (!rovers.isEmpty()) {
     break;
    } else {
     // else, there was not a complete set of input to at least rover, and 
     // hence, empty input is not considered as end of input, but
     // an error. So, throw exception.
     sc.close();
     throw new IllegalArgumentException("Input cannot be an empty.");
    }
   }

   inputDataSequence.getInputDataReader(i).readAndInitialize(rover, input);

  } while (sc.hasNextLine());
  sc.close();

  return rovers;
 }
}