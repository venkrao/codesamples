package com.nasa.marsrover.explore;

import com.nasa.marsrover.Rover;

/**
 * Interface used by various "Instructions" to rover.
 * such as L(RotateLeft) R(RotateRight) M(MoveForward)
 * 
 * @author veraoks
 *
 */

public interface Instruction {
 public void execute(Rover rover);
}