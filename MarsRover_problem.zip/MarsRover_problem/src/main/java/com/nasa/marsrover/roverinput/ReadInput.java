package com.nasa.marsrover.roverinput;

import com.nasa.marsrover.Rover;

public interface ReadInput {
 public void readAndInitialize(Rover rover, String input);
}