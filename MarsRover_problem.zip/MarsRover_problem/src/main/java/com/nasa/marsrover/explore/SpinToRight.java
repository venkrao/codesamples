package com.nasa.marsrover.explore;

import com.nasa.marsrover.Rover;

/**
 * Executes the command "R" which spins the rover to right.
 * After spinning, the only attribute that changes is the 
 * facing direction of the rover.
 * Hence, after spin, the HeadingDirection of the rover is updated.
 * 
 * @author veraoks
 *
 */

public class SpinToRight implements Instruction {

 @Override
 public void execute(Rover rover) throws IllegalArgumentException {

  if (rover.getHeadingDirection().equals("E")) {
   rover.getCurrentPosition().setHeadingDirection("S");
   return;
  }

  if (rover.getHeadingDirection().equals("S")) {
   rover.getCurrentPosition().setHeadingDirection("W");
   return;
  }

  if (rover.getHeadingDirection().equals("W")) {
   rover.getCurrentPosition().setHeadingDirection("N");
   return;
  }

  if (rover.getHeadingDirection().equals("N")) {
   rover.getCurrentPosition().setHeadingDirection("E");
   return;
  }

  // which is because the "headingdirection" is not konwn.
  // not because the rover cannot spin!
  // catching that invalid Heading direction case..

  throw new IllegalArgumentException("Rover is facing facing direction: " 
  + rover.getHeadingDirection());
 }

}