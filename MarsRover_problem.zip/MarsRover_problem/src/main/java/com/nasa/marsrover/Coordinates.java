/**
 * Coordinates class.
 * Author: Venkatakrishna Rao K S
 */

package com.nasa.marsrover;
public class Coordinates {
 private int x;
 private int y;
 public Coordinates(int x, int y) {
  this.x = x;
  this.y = y;
 }
 public Coordinates() {}
 public void decrementCoordinates(String axis, int decrementBy) {
  if (axis.toLowerCase().equals("x")) {
   this.x = this.x - decrementBy;
  }
  if (axis.toLowerCase().equals("y")) {
   this.y = this.y - decrementBy;
  }
 }
 public void incrementCoordinates(String axis, int incrementBy) {
   if (axis.toLowerCase().equals("x")) {
    this.x = this.x + incrementBy;
   }
   if (axis.toLowerCase().equals("y")) {
    this.y = this.y + incrementBy;
   }
  }
  /**
   * Returns the x coordinate value.
   * @return x coordinate value.
   */
 public int getX() {
   return this.x;
  }
  /**
   * Returns the y coordinate value.
   * @return y coordinate value.
   */
 public int getY() {
  return this.y;
 }
 public String getCoordinatesAsString() {
  return (String.format("%d %d", this.getX(), this.getY()));
 }
 public void setCoordinatesFromString(String coordinatesAsString) {
  String[] coordinatesArray = coordinatesAsString.split("\\s+");
  if (coordinatesArray.length != 2) {
   throw new IllegalArgumentException("Invalid coordinates: " + coordinatesAsString);
  }
  try {
   this.x = Integer.parseInt(coordinatesArray[0]);
   this.y = Integer.parseInt(coordinatesArray[1]);
  } catch (NumberFormatException e) {
   System.out.println(
    "Coordinates are to be numbers. Current coordinates are thus invalid: " + coordinatesAsString);
   e.printStackTrace();
  }
 }
 public boolean areCoordinatesNegative() {
  if (this.x < 0 || this.y < 0) {
   return true;
  }
  return false;
 }
}