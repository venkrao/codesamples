package com.nasa.marsrover;

/**
 *  The main class.
 *  Author: Venkatakrishna Rao K S
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;


public class MarsRoverMain {

 public static void main(String[] args) {

  InitializeRovers init = new InitializeRovers();

  // Contains all rovers.
  ArrayList < Rover > rovers = new ArrayList < Rover > ();

  // Initialize rovers with input data read from stdin
  if (args.length == 0) {
   rovers = init.readRoversInput(new Scanner(System.in));
  }

  // Initialize rovers with input data read from file at args[1]
  if (args.length == 1) {
   File marsRoverInput = new File(args[0]);
   try {
    rovers = init.readRoversInput(new Scanner(marsRoverInput));
   } catch (FileNotFoundException e) {
    System.err.println("Argument 1 needs to be a file with valid input to rovers.");
    e.printStackTrace();
    return;
   }
  }

  if (rovers.isEmpty()) {
   System.err.print("There are no rovers to explore plateau.");
   return;
  }

  // Let rovers explore as per the given instructions.
  for (int i = 0; i < rovers.size(); i++) {
   rovers.get(i).explorePlateau();
   System.out.println(rovers.get(i).getCurrentPositionAsString());
  }
 }

}