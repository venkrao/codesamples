package com.nasa.marsrover.roverinput;

/**
 * Reads rover start position.
 * 
 * @author Venkatakrishna Rao K S 
 */

import com.nasa.marsrover.Rover;
import com.nasa.marsrover.RoverPosition;

public class ReadRoverStartPosition implements ReadInput {

 @Override
 public void readAndInitialize(Rover rover, String roverPositionString) {
  RoverPosition roverStartingPosition = new RoverPosition();

  roverStartingPosition.setCoordinatesFromPositionString(roverPositionString);
  roverStartingPosition.setHeadingDirectionFromPositionString(roverPositionString);

  if (roverStartingPosition.getRoverPositionCoordinates().areCoordinatesNegative()) {
   throw new IllegalArgumentException("Rover position coordinates cannot be negative.");
  }
  rover.setStartPosition(roverStartingPosition);
 }

}