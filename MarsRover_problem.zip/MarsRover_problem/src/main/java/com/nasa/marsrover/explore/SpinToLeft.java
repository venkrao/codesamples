package com.nasa.marsrover.explore;

import com.nasa.marsrover.Rover;

/**
 * Executes the command "L" which spins the rover to left.
 * After spinning, the only attribute that changes is the 
 * facing direction of the rover.
 * Hence, after spin, the HeadingDirection of the rover is updated.
 * 
 * @author Venkatakrishna Rao K S
 *
 */

public class SpinToLeft implements Instruction {

 /**
  * Execute the "L" command, and update RoverHeadingDirection.
  */
 @Override
 public void execute(Rover rover) throws IllegalArgumentException {

  if (rover.getHeadingDirection().equals("E")) {
   rover.getCurrentPosition().setHeadingDirection("N");
   return;
  }

  if (rover.getHeadingDirection().equals("S")) {
   rover.getCurrentPosition().setHeadingDirection("E");
   return;
  }

  if (rover.getHeadingDirection().equals("W")) {
   rover.getCurrentPosition().setHeadingDirection("S");
   return;
  }

  if (rover.getHeadingDirection().equals("N")) {
   rover.getCurrentPosition().setHeadingDirection("W");
   return;
  }

  throw new IllegalArgumentException("Rover is facing facing direction: " 
  + rover.getHeadingDirection());
 }

}