package com.nasa.marsrover;
/**
 * Position of rover, which is axis coordinates, and the 
 * heading direction of the rover.
 * 
 */
public class RoverPosition {

 private Coordinates positionCoordinates;
 private String headingDirection;

 public RoverPosition(Coordinates c, String d) {
  this.positionCoordinates = c;
  this.headingDirection = d;
 }

 public RoverPosition() {}

 public String getHeadingDirection() {
  return this.headingDirection;
 }

 public Coordinates getRoverPositionCoordinates() {
  return this.positionCoordinates;
 }

 public void setRoverPositionCoordinates(Coordinates c) {
  this.positionCoordinates = c;
 }

 /**
  * Read the position string, and set the coordinates accordingly.
  * 
  * @param positionString The position string, which is reads like 1 2 N
  * @throws NumberFormatException
  * @throws IllegalArgumentException
  */
 public void setCoordinatesFromPositionString(String positionString) 
     throws NumberFormatException, IllegalArgumentException {
  String[] coordinatesArray = positionString.split("\\s+");

  if (coordinatesArray.length < 2) {
   throw new IllegalArgumentException("Coordinates in the position string are invalid " 
  + positionString);
  }
  try {
   int x = Integer.parseInt(coordinatesArray[0]);
   int y = Integer.parseInt(coordinatesArray[1]);
   this.positionCoordinates = new Coordinates(x, y);
  } catch (NumberFormatException n) {
   throw new NumberFormatException("Non numeric characters in rover position string " 
  + positionString);
  }

 }

 public void setHeadingDirection(String heading) {
  this.headingDirection = heading;
 }

 public void setHeadingDirectionFromPositionString(String positionString) 
     throws NumberFormatException {
  String[] positionStringArray = positionString.split("\\s+");
  if (positionStringArray.length < 3) {
   System.out.println("Position string doesn't seem to contain heading direction: " 
  + positionString);
   System.exit(1);
  }
  try {
   this.setHeadingDirection(positionStringArray[2]);
  } catch (NumberFormatException n) {
   System.out.println("Invalid characters in rover position string\n" + positionString);
   n.printStackTrace();
  }
 }


}