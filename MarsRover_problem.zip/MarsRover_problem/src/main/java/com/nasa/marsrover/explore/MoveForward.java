package com.nasa.marsrover.explore;

import com.nasa.marsrover.Rover;

/**
 * Abiding by "single responsibility principle"
 * and "Interface segregation principle."
 * 
 * by making InstructionExecutionFeasibility:execute a seperate interface method
 * and not a member of Instruction interface itself, as feasibility check is not needed
 * for TurnLeft, and TurnRight classes as it is perfectly feasible
 * all the time for the rovers to turn left, or right for the requirements known.
 * 
 * @author Venkatakrishna Rao K S
 *
 */
public class MoveForward implements Instruction, InstructionExecutionFeasibility {

 // As of now, M moves the rover by 1 grid point.
 private int moveRoverBy = 1;

 /**
  * Executes instruction "M", which moves the rover along 
  * one of the X or Y coordinates, thus, incrementing
  * x or y coordinate values by 1.
  */
 @Override
 public void execute(Rover rover) throws IllegalArgumentException {

  if (!this.isFeasibleAction(rover)) {
   throw new IllegalArgumentException("MoveForward will head off the axis if executed." 
  + " Aborting navigation.");
  }

  if (rover.getHeadingDirection().equals("E")) {
   rover.getCurrentPositionCoordinates().incrementCoordinates("X", moveRoverBy);
   return;
  }

  if (rover.getHeadingDirection().equals("W")) {
   rover.getCurrentPositionCoordinates().decrementCoordinates("X", moveRoverBy);
   return;
  }

  if (rover.getHeadingDirection().equals("N")) {
   rover.getCurrentPositionCoordinates().incrementCoordinates("Y", moveRoverBy);
   return;
  }

  if (rover.getHeadingDirection().equals("S")) {
   rover.getCurrentPositionCoordinates().decrementCoordinates("Y", moveRoverBy);
   return;
  }

  throw new IllegalArgumentException("Can't MoveForward, as rover is facing unrecognized "
      + "direction.");
 }

 /**
  * Checks if MoveForward can be executed from current Position of the Rover.
  * Rover should not head outside plateau.
  */
 @Override
 public boolean isFeasibleAction(Rover rover) throws IllegalArgumentException {

  if (rover.getHeadingDirection().equals("E")) {
   if (rover.getCurrentPositionCoordinates().getX() ==
    rover.getPlateau().getLowerRightCoordinates().getX()) {
    throw new IllegalArgumentException("Rover heads off plateau in east if moves forward.");
   }
  }

  if (rover.getHeadingDirection().equals("W")) {
   if (rover.getCurrentPositionCoordinates().getX() ==
    rover.getPlateau().getLowerLeftCoordinates().getX()) {
    throw new IllegalArgumentException("Rover heads off plateau in west if moves forward.");
   }
  }

  if (rover.getHeadingDirection().equals("N")) {
   if (rover.getCurrentPositionCoordinates().getY() ==
    rover.getPlateau().getUpperRightCoordinates().getY()) {
    throw new IllegalArgumentException("Rover heads off plateau in north if moves forward.");
   }
  }

  if (rover.getHeadingDirection().equals("S")) {
   if (rover.getCurrentPositionCoordinates().getY() ==
    rover.getPlateau().getLowerRightCoordinates().getY()) {
    throw new IllegalArgumentException("Rover heads off plateau in south if moves forward.");
   }
  }
  return true;
 }
}