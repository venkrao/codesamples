package com.nasa.marsrover;

/**
 * The Rover.
 */

import java.util.HashMap;

import com.nasa.marsrover.explore.Instruction;
import com.nasa.marsrover.explore.InstructionAction;

public class Rover {
 private Plateau plateau;
 private RoverPosition currentPosition;
 private String instructionsToExplore;
 private RoverPosition startPosition;

 public Rover(Plateau p, RoverPosition startPosition, String instructions) {
  this.plateau = p;
  this.startPosition = startPosition;
  this.instructionsToExplore = instructions;

  // Before executing any instruction to navigate the plateau,
  // the rovers' currentPosition is same as startPosition.
  this.currentPosition = startPosition;
 }

 public Rover() {
  this.plateau = null;
  this.currentPosition = null;
  this.instructionsToExplore = null;
  this.startPosition = null;
 }


 public void setPlateau(Plateau p) {
  this.plateau = p;
 }

 public void setInstructions(String s) {
  this.instructionsToExplore = s;
 }

 public void setStartPosition(RoverPosition startPosition) {
  this.startPosition = startPosition;

  // Also initialize the currentPosition in the same!
  this.currentPosition = startPosition;
 }


 public RoverPosition getCurrentPosition() {
  return this.currentPosition;
 }

 public String getCurrentPositionAsString() {
  return (String.format("%s %s", 
      this.startPosition.getRoverPositionCoordinates().getCoordinatesAsString(),
      this.currentPosition.getHeadingDirection()));
 }

 public String getStartPositionAsString() {
  return (String.format("%s %s", 
      this.startPosition.getRoverPositionCoordinates().getCoordinatesAsString(), 
      this.currentPosition.getHeadingDirection()));
 }

 /**
  * 
  * @return Heading direction of rover as string.
  */
 public String getHeadingDirection() {
  return this.getCurrentPosition().getHeadingDirection();
 }

 /**
  * 
  * @return Current position coordinates.
  */
 public Coordinates getCurrentPositionCoordinates() {
  return this.getCurrentPosition().getRoverPositionCoordinates();
 }


 public String getRoverNavigationInstructions() {
  return this.instructionsToExplore;
 }

 /**
  * Start navigating the plateau as per the given instructions.
  * @throws IllegalArgumentException
  */
 public void explorePlateau() throws IllegalArgumentException {
  String[] instructions = this.instructionsToExplore.split("");

  // Contains Instruction to its action mapping.
  InstructionAction initInst = new InstructionAction();

  HashMap < String, Instruction > actions = initInst.getInstructionActions();

  for (int i = 0; i < instructions.length; i++) {
   if (!actions.containsKey(instructions[i])) {
    throw new IllegalArgumentException(
        String.format("Don't know how to execute Instruction: %s", instructions[i]));
   }
   // Execute the given instruction, and update rovers position coordinates,
   // and facing direction accordingly.
   try {
    actions.get(instructions[i]).execute(this);
   } catch (IllegalArgumentException e) {
    System.err.println(String.format(
        "Illegal instruction %s at character position %d", instructions[i], i + 1));
    e.printStackTrace();
    System.exit(1);
   }
  }
 }

 /**
  * 
  * @return The plateau this rover is expected to navigate.
  */
 public Plateau getPlateau() {
  return this.plateau;
 }
}