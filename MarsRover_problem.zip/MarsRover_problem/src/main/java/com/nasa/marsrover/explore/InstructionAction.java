package com.nasa.marsrover.explore;

/**
 * Should a new instruction come in future, 
 * updating this class' HashMap, and providing 
 * the right action implementation in its corresponding
 * class that implements the Instruction interface
 * should do the job.
 * 
 * Abiding by "open/closed principle"
 * 
 * Author: Venkatakrishna Rao K S
 */
import java.util.HashMap;

public class InstructionAction {
 private HashMap < String, Instruction > instructionToActionMap = new HashMap < > ();

 /**
  * Public constructor.
  * Should a new instruction come in fugure, 
  * updating this hashMap, and providing 
  * the right action implementation in its corresponding
  * class that implements Instruction interface
  * should do the job.
  */
 public InstructionAction() {
  this.instructionToActionMap.put("L", new SpinToLeft());
  this.instructionToActionMap.put("R", new SpinToRight());
  this.instructionToActionMap.put("M", new MoveForward());
 }

 /**
  * 
  * @return Instruction to action mapping.
  */
 public HashMap < String, Instruction > getInstructionActions() {
  return this.instructionToActionMap;
 }
}