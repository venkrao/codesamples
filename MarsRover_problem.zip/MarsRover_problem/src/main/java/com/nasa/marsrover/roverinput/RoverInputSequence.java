package com.nasa.marsrover.roverinput;

import java.util.HashMap;

/**
 * As of now, input is read in a predefined format.
 * 1. The plateau upper right coordinates
 * 2. Input to 1st rover - its start position coordinates, and heading direction
 * 3. Input to 1st rover - its instructions to explore plateau
 * 4. Input to 2nd rover - its start position coordinates, and heading direction
 * 5. Input to 2nd rover - its instructions to explore plateau
 * 
 * Looking at this logical order, the following HashMap has been implemented.
 * 
 * @author Venkatakrishna Rao K S
 *
 */

public class RoverInputSequence {
 private HashMap < Integer, ReadInput > readInputSequence = new HashMap < > ();

 public RoverInputSequence() {
  this.readInputSequence.put(1, new ReadRoverStartPosition());
  this.readInputSequence.put(2, new ReadRoverNavigationInstructions());
 }

 public HashMap < Integer, ReadInput > getInputDataSequence() {
  return this.readInputSequence;
 }

 public ReadInput getInputDataReader(int i) {
  return this.readInputSequence.get(i);
 }

 public int getTotalInputDataItems() {
  return this.readInputSequence.size();
 }

}