package com.nasa.marsrover.roverinput;

/**
 * Interface ValidateInput
 * Implemented by those instructions that should validate the instruction
 * before executing.
 * 
 * @author Venkatakrishna Rao K S
 *
 */
public interface ValidateInput {
 public boolean validate(String instructions);
}