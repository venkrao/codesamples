package com.nasa.marsrover;

/**
 * Contains attributes of the Plateau.
 * As of now, just upperRight, and lowerLeft coordinates.
 * @author Venkatakrishna Rao K S
 *
 */
public class Plateau {
 private Coordinates upperRightCoordinates;
 private Coordinates lowerLeftCoordinates;

 public Plateau(Coordinates upperRightCoordinates) {
  this.upperRightCoordinates = upperRightCoordinates;
  this.lowerLeftCoordinates = new Coordinates(0, 0);
 }

 /**
  * @return Coordinates corresponding to upperRight corner of plateau.
  */
 public Coordinates getUpperRightCoordinates() {
  return this.upperRightCoordinates;
 }

 /**
  * @return Coordinates corresponding to upperRight corner of plateau.
  */
 public Coordinates getLowerLeftCoordinates() {
  return this.lowerLeftCoordinates;
 }

 /**
  * 
  * @return Coordinates corresponding to lowerRight coordinates
  */
 public Coordinates getLowerRightCoordinates() {
  return new Coordinates(this.upperRightCoordinates.getX(), this.lowerLeftCoordinates.getY());
 }


 /**
  * @return Coordinates corresponding to lowerLeft coordinates 
  */
 public Coordinates getUpperLeftCoordinates() {
  return new Coordinates(this.lowerLeftCoordinates.getX(), this.upperRightCoordinates.getY());
 }
}