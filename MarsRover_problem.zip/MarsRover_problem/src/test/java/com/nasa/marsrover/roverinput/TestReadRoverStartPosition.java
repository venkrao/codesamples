package com.nasa.marsrover.roverinput;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.nasa.marsrover.Rover;
import com.nasa.marsrover.roverinput.ReadRoverStartPosition;

public class TestReadRoverStartPosition {

 @Test
 public void ReadAndInitializeShouldInitializeStartPosition() {
  Rover r = new Rover();
  ReadRoverStartPosition readRoverStartPosition = new ReadRoverStartPosition();
  readRoverStartPosition.readAndInitialize(r, "1 2 N");

  assertEquals("1 2 N", r.getCurrentPositionAsString());
 }

 @Rule
 public ExpectedException thrown = ExpectedException.none();

 @Test
 public void ReadAndInitializeShouldThrowIllegalArgumentExceptionifStartPositionIsHavingNegativeXCoordinates() {
  Rover r = new Rover();
  ReadRoverStartPosition readRoverStartPosition = new ReadRoverStartPosition();

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Rover position coordinates cannot be negative.");
  readRoverStartPosition.readAndInitialize(r, "-1 2 N");

 }



 @Test
 public void ReadAndInitializeShouldThrowIllegalArgumentExceptionifStartPositionIsHavingNegativeYCoordinates() {
  Rover r = new Rover();
  ReadRoverStartPosition readRoverStartPosition = new ReadRoverStartPosition();

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Rover position coordinates cannot be negative.");
  readRoverStartPosition.readAndInitialize(r, "1 -2 N");

 }

}