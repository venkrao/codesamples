package com.nasa.marsrover;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestRoverPosition {

 @Test
 public void getHeadingDirectionShouldReturnHeadingDirection() {
  RoverPosition r = new RoverPosition(new Coordinates(1, 2), "E");

  assertEquals("E", r.getHeadingDirection());
 }

 @Test
 public void getRoverPositionCoordinatesShouldReturnPositionCoordinates() {
  RoverPosition r = new RoverPosition(new Coordinates(1, 2), "E");

  assertEquals("1 2", r.getRoverPositionCoordinates().getCoordinatesAsString());
 }

 @Test
 public void testSetRoverHeadingDirection() {
  RoverPosition r = new RoverPosition();
  r.setCoordinatesFromPositionString("1 2");
  r.setHeadingDirection("S");

  assertEquals("S", r.getHeadingDirection());
 }

 @Test
 public void testSetRoverPositionCoordinates() {
  RoverPosition r = new RoverPosition();
  r.setRoverPositionCoordinates(new Coordinates(1, 2));
  r.setHeadingDirection("S");

  assertEquals("1 2", r.getRoverPositionCoordinates().getCoordinatesAsString());
 }

 @Test
 public void testSetCoordinatesFromPositionString() {
  RoverPosition r = new RoverPosition();
  r.setCoordinatesFromPositionString("1 2");
  r.setHeadingDirection("S");

  assertEquals("1 2", r.getRoverPositionCoordinates().getCoordinatesAsString());
 }

 @Test
 public void testSetHeadingDirection() {
  RoverPosition r = new RoverPosition();
  r.setCoordinatesFromPositionString("1 2");
  r.setHeadingDirection("S");

  assertEquals("S", r.getHeadingDirection());
 }

 @Test
 public void testSetHeadingDirectionFromPositionString() {
  RoverPosition r = new RoverPosition();
  r.setCoordinatesFromPositionString("1 2");
  r.setHeadingDirectionFromPositionString("1 E E");

  assertEquals("E", r.getHeadingDirection());

 }

}