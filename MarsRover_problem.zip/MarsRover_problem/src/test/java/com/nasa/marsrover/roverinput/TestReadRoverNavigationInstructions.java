package com.nasa.marsrover.roverinput;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.nasa.marsrover.Rover;
import com.nasa.marsrover.roverinput.ReadRoverNavigationInstructions;

public class TestReadRoverNavigationInstructions {

 @Rule
 public ExpectedException thrown = ExpectedException.none();

 @Test
 public void readAndInitializeShouldThrowIllegalArgumentsExceptionIfInputInstructionsAreEmpty() {
  ReadRoverNavigationInstructions readInstructions = new ReadRoverNavigationInstructions();
  Rover r = new Rover();
  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Empty string received in place of instructions to explore plateau!");
  readInstructions.readAndInitialize(r, "");
 }

 @Test
 public void readAndInitializeShouldInitializeRoverNavigationInstructions() {
  ReadRoverNavigationInstructions readInstructions = new ReadRoverNavigationInstructions();
  Rover r = new Rover();

  readInstructions.readAndInitialize(r, "LRM");

  assertEquals(r.getRoverNavigationInstructions(), "LRM");
 }

 @Test
 public void validateShouldThrowIllegalArgumentExceptionIfInstructionContainsIllegalCharacters() {
  ReadRoverNavigationInstructions readInstructions = new ReadRoverNavigationInstructions();
  Rover r = new Rover();

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Invalid instruction character: X");

  readInstructions.validate("X");

 }

 @Test
 public void validateShouldReturnTrueForInstructionL() {
  ReadRoverNavigationInstructions readInstructions = new ReadRoverNavigationInstructions();
  Rover r = new Rover();

  assertEquals(true, readInstructions.validate("L"));

 }

 @Test
 public void validateShouldReturnTrueForInstructionR() {
  ReadRoverNavigationInstructions readInstructions = new ReadRoverNavigationInstructions();
  Rover r = new Rover();

  assertEquals(true, readInstructions.validate("R"));

 }

 @Test
 public void validateShouldReturnTrueForInstructionM() {
  ReadRoverNavigationInstructions readInstructions = new ReadRoverNavigationInstructions();
  Rover r = new Rover();

  assertEquals(true, readInstructions.validate("M"));

 }
}