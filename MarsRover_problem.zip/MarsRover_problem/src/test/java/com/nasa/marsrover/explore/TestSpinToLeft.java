package com.nasa.marsrover.explore;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.nasa.marsrover.Coordinates;
import com.nasa.marsrover.Plateau;
import com.nasa.marsrover.Rover;
import com.nasa.marsrover.RoverPosition;
import com.nasa.marsrover.explore.SpinToLeft;

public class TestSpinToLeft {

 @Rule
 public ExpectedException thrown = ExpectedException.none();

 @Test
 public void executeOnSpinToLeftShouldSpinToWestWhenFacingSouth() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "L";
  RoverPosition startPosition = new RoverPosition(new Coordinates(5, 0), "S");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  SpinToLeft spinToLeft = new SpinToLeft();

  spinToLeft.execute(r);
  assertEquals(r.getHeadingDirection(), "E");
 }


 @Test
 public void executeOnSpinToLeftShouldSpinToNorthWhenFacingWest() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "L";
  RoverPosition startPosition = new RoverPosition(new Coordinates(5, 0), "W");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  SpinToLeft spinToLeft = new SpinToLeft();

  spinToLeft.execute(r);
  assertEquals(r.getHeadingDirection(), "S");
 }

 @Test
 public void executeOnSpinToLeftShouldSpinToEastWhenFacingNorth() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "L";
  RoverPosition startPosition = new RoverPosition(new Coordinates(5, 0), "N");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  SpinToLeft spinToLeft = new SpinToLeft();

  spinToLeft.execute(r);
  assertEquals(r.getHeadingDirection(), "W");
 }

 @Test
 public void executeOnSpinToLeftShouldSpinToSouthWhenFacingEast() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "L";
  RoverPosition startPosition = new RoverPosition(new Coordinates(5, 0), "E");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  SpinToLeft spinToLeft = new SpinToLeft();

  spinToLeft.execute(r);
  assertEquals(r.getHeadingDirection(), "N");
 }

 @Test
 public void executeOnSpinToLeftShouldThrowExceptionWhenFacingUnknownDirection() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "L";
  RoverPosition startPosition = new RoverPosition(new Coordinates(5, 0), "X");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  SpinToLeft spinToLeft = new SpinToLeft();
  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Rover is facing facing direction: X");

  spinToLeft.execute(r);
 }


}