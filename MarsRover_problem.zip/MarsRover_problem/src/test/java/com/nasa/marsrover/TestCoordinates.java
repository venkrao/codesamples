package com.nasa.marsrover;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestCoordinates {
 @Test
 public void decrementCoordinatesForXShouldDecrementXCoordinate() {
  Coordinates c = new Coordinates(3, 4);
  c.decrementCoordinates("x", 1);
  assertEquals(2, c.getX());
 }

 @Test
 public void decrementCoordinatesForYShouldDecrementYCoordinate() {
  Coordinates c = new Coordinates(3, 4);
  c.decrementCoordinates("Y", 1);
  assertEquals(3, c.getY());
 }

 @Test
 public void incrementCoordinatesForXShouldIncrementXCorodinate() {
  Coordinates c = new Coordinates(3, 5);
  c.incrementCoordinates("X", 1);
  assertEquals(4, c.getX());
 }

 @Test
 public void incrementCoordinatesForYShouldIncrementYCorodinate() {
  Coordinates c = new Coordinates(3, 5);
  c.incrementCoordinates("Y", 1);
  assertEquals(6, c.getY());
 }

 @Test
 public void getCoordinatesAsStringShouldReturnCoordinatesAsStringSeperatedBySingleSpace() {
  Coordinates c = new Coordinates(3, 5);
  String coordinatesAsString = "3 5";
  assertEquals(coordinatesAsString, c.getCoordinatesAsString());
 }

 @Test
 public void stringToCoordinatesShouldReturnCoordinatesObjectWithXAndYCoordinatesSet() {
  Coordinates lhs = new Coordinates(3, 4);
  String coordinatesAsString = "3 4";
  Coordinates rhs = new Coordinates();
  rhs.setCoordinatesFromString(coordinatesAsString);
  assertEquals(lhs.getCoordinatesAsString(), rhs.getCoordinatesAsString());
 }


 @Test
 public void setCoordinatesFromStringShouldSetCoordinates() {
  String coordinatesString = "1 2";
  Coordinates c = new Coordinates();
  c.setCoordinatesFromString(coordinatesString);
  assertEquals(c.getCoordinatesAsString(), coordinatesString);
 }

}