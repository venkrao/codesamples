package com.nasa.marsrover;

public class TestInstructionAction {
 /**
  * Perhaps checking if the members of the HashMap in InstructionAction
  * all implement the interface Instruction is one test.
  * 
  * But without that, nothing works. So, I believe, its ok to ignore it.
  */

}