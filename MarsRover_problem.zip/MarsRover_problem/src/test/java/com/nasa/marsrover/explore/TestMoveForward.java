package com.nasa.marsrover.explore;

import static org.junit.Assert.*;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.nasa.marsrover.Coordinates;
import com.nasa.marsrover.Plateau;
import com.nasa.marsrover.Rover;
import com.nasa.marsrover.RoverPosition;
import com.nasa.marsrover.explore.MoveForward;

public class TestMoveForward {

 /**
  * 2 rules to validate "increment" axis value when rover moves to east, or north.
  */
 @Test
 public void executeShouldIncrementXCoordinatesByDefinedValueWhenHeadingEast() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(0, 2), "E");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward moveToEast = new MoveForward();
  moveToEast.execute(r);

  assertEquals(1, r.getCurrentPosition().getRoverPositionCoordinates().getX());
 }

 @Test
 public void executeShouldIncrementYCoordinatesByDefinedValueWhenHeadingNorth() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(0, 2), "N");

  Rover rover = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward toNorth = new MoveForward();
  toNorth.execute(rover);

  assertEquals(3, rover.getCurrentPosition().getRoverPositionCoordinates().getY());
 }

 /**
  * 2 rules to validate "decrement" axis value when rover moves to W, or S.
  */
 @Test
 public void executeShouldDecrementXCoordinatesByDefinedValueWhenHeadingWest() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(1, 2), "W");

  Rover rover = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward toWest = new MoveForward();
  toWest.execute(rover);

  assertEquals(0, rover.getCurrentPosition().getRoverPositionCoordinates().getX());
 }

 @Test
 public void executeShouldDecrementYCoordinatesByDefinedValueWhenHeadingSouth() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(0, 2), "S");

  Rover rover = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward toSouth = new MoveForward();
  toSouth.execute(rover);

  assertEquals(1, rover.getCurrentPosition().getRoverPositionCoordinates().getY());
 }


 /**
  * 4 rules to verify only desired axis value changes, and nothing else.
  */

 @Test
 public void executeShouldNotChangeYCoordinatesWhenHeadingEast() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(0, 2), "E");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward moveToEast = new MoveForward();
  moveToEast.execute(r);

  assertEquals(2, r.getCurrentPosition().getRoverPositionCoordinates().getY());
 }

 @Test
 public void executeShouldNotChangeYCoordinatesWhenHeadingWest() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(1, 2), "W");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward moveToWest = new MoveForward();
  moveToWest.execute(r);

  assertEquals(2, r.getCurrentPosition().getRoverPositionCoordinates().getY());
 }

 @Test
 public void executeShouldNotChangeXCoordinatesWhenHeadingNorth() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(1, 2), "N");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward moveToNorth = new MoveForward();
  moveToNorth.execute(r);

  assertEquals(1, r.getCurrentPosition().getRoverPositionCoordinates().getX());
 }

 @Test
 public void executeShouldNotChangeXCoordinatesWhenHeadingSouth() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(1, 2), "S");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward moveToSouth = new MoveForward();
  moveToSouth.execute(r);

  assertEquals(1, r.getCurrentPosition().getRoverPositionCoordinates().getX());
 }

 /**
  * Exceptions should be thrown when rover is heading beyond the given plateau
  * boundary coordinates.
  */

 @Rule
 public ExpectedException thrown = ExpectedException.none();

 @Test
 public void executeShouldThrowExceptionIfGivenInstructionHeadsTheRoverOffWestBoundary() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(0, 2), "W");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward moveToWest = new MoveForward();

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Rover heads off plateau in west if moves forward.");

  moveToWest.execute(r);
 }

 @Test
 public void executeShouldThrowExceptionIfGivenInstructionHeadsTheRoverOffEastBoundary() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(5, 1), "E");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward moveToEast = new MoveForward();

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Rover heads off plateau in east if moves forward.");

  moveToEast.execute(r);
 }

 @Test
 public void executeShouldThrowExceptionIfGivenInstructionHeadsTheRoverOffSouthBoundary() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(5, 0), "S");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward moveToEast = new MoveForward();

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Rover heads off plateau in south if moves forward.");

  moveToEast.execute(r);
 }

 @Test
 public void executeShouldThrowExceptionIfGivenInstructionHeadsTheRoverOffNorthBoundary() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPosition = new RoverPosition(new Coordinates(0, 5), "N");

  Rover r = new Rover(plateau, startPosition, instructionsToExplore);

  MoveForward moveToEast = new MoveForward();

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Rover heads off plateau in north if moves forward.");

  moveToEast.execute(r);
 }

 /**
  * When invalid instruction letter is passed to the MoveForward
  */

 @Test
 public void executeShouldThrowIllegalArgumentExceptionWhenInvalidHeadingDirectionIsGiven() {
  Plateau plateau = new Plateau(new Coordinates(5, 5));
  String instructionsToExplore = "M";
  RoverPosition startPositionWithInvalidFacingDirection = new RoverPosition(new Coordinates(0, 5), "D");

  Rover r = new Rover(plateau, startPositionWithInvalidFacingDirection, instructionsToExplore);

  MoveForward move = new MoveForward();
  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Can't MoveForward, as rover is facing unrecognized direction.");
  move.execute(r);
 }

}