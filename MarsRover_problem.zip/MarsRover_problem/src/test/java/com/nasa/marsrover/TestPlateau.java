package com.nasa.marsrover;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestPlateau {

 @Test
 public void testGetLowerRightCoordinates() {
  Plateau p = new Plateau(new Coordinates(5, 5));

  assertEquals(p.getLowerRightCoordinates().getCoordinatesAsString(), "5 0");
 }

 @Test
 public void testGetUpperLeftCoordinates() {
  Plateau p = new Plateau(new Coordinates(5, 5));

  assertEquals(p.getUpperLeftCoordinates().getCoordinatesAsString(), "0 5");
 }

 // They are (0,0) as of now. as per the requirements known.
 @Test
 public void testLowerLeftCoordinates() {
  Plateau p = new Plateau(new Coordinates(5, 5));

  assertEquals(p.getLowerLeftCoordinates().getCoordinatesAsString(), "0 0");
 }

 @Test
 public void testUpperRightCoordinates() {
  Plateau p = new Plateau(new Coordinates(5, 4));

  assertEquals(p.getUpperRightCoordinates().getCoordinatesAsString(), "5 4");
 }

}