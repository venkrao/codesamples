package com.nasa.marsrover;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestRover {

 @Test
 public void testGetCurrentPositionAsString() {
  Rover r = new Rover();

  // set startPosition also sets currentPosition.
  r.setStartPosition(new RoverPosition(new Coordinates(1, 2), "N"));
  assertEquals("1 2 N", r.getCurrentPositionAsString());
 }

 @Test
 public void testGetStartPositionAsString() {
  Rover r = new Rover();

  r.setStartPosition(new RoverPosition(new Coordinates(3, 2), "E"));
  assertEquals("3 2 E", r.getCurrentPositionAsString());
 }

}