package com.nasa.marsrover;

import static org.junit.Assert.*;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

public class TestInitializeRovers {

 @Rule
 public ExpectedException thrown = ExpectedException.none();

 @Test
 public void initializeRoversShouldThrowIllegalArgumentsExceptionIfPlateauCoordinatesAreEmpty() {
  // As they are the first ones in the input as of now,
  // if no input is given, we throw exceptoin for PlateauUpperRightCoordinates

  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String emptyInput = "\n1 2 N\nMLM\n";

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Plateau coordinates cannot be left empty.");

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(emptyInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }
 }

 @Test
 public void initializeRoversShouldInitializePlateauBoundaryCoordinates() {
  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String roverInput = "5 5\n1 2 W\nLRM\n\n";

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(roverInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }

  assertEquals(rovers.get(0).getPlateau().getUpperRightCoordinates().getCoordinatesAsString(), "5 5");

 }

 @Test
 public void initializeRoversShouldInitializePlateauUpperRightCoordinates() {
  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String roverInput = "4 5\n1 2 W\nLRM\n\n";

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(roverInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }

  assertEquals(rovers.get(0).getPlateau().getUpperRightCoordinates().getCoordinatesAsString(), "4 5");

 }

 @Test
 public void initializeRoversShouldInitializePlateauUpperLeftCoordinates() {
  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String roverInput = "5 5\n1 2 W\nLRM\n\n";

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(roverInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }

  assertEquals(rovers.get(0).getPlateau().getUpperLeftCoordinates().getCoordinatesAsString(), "0 5");

 }

 @Test
 public void initializeRoversShouldInitializePlateauLowerLeftCoordinates() {
  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String roverInput = "5 5\n1 2 W\nLRM\n\n";

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(roverInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }

  assertEquals(rovers.get(0).getPlateau().getLowerLeftCoordinates().getCoordinatesAsString(), "0 0");

 }

 @Test
 public void initializeRoversShouldInitializePlateauLowerRightCoordinates() {
  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String roverInput = "5 5\n1 2 W\nLRM\n\n";

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(roverInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }

  assertEquals(rovers.get(0).getPlateau().getLowerRightCoordinates().getCoordinatesAsString(), "5 0");

 }

 @Test
 public void initializeRoversShouldInitializeRoverStartPosition() {
  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String roverInput = "5 5\n1 2 W\nLRM\n\n";

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(roverInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }

  assertEquals(rovers.get(0).getStartPositionAsString(), "1 2 W");

 }

 @Test
 public void initializeRoversShouldInitializeRoverHeadingDirection() {
  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String roverInput = "5 5\n1 2 W\nLRM\n\n";

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(roverInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }

  assertEquals(rovers.get(0).getHeadingDirection(), "W");

 }

 @Test
 public void initializeRoversShouldInitializeInstructionsToExplorePlateau() {
  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String roverInput = "5 5\n1 2 W\nLRM\n\n";

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(roverInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }

  assertEquals(rovers.get(0).getRoverNavigationInstructions(), "LRM");

 }

 /**
  * Throw exception if required fields are not set.
  */

 @Test
 public void initializeRoversShouldThrowIllegalArgumentsExceptionIfPlateauCoordinatesAreNegative() {
  // As they are the first ones in the input as of now,
  // if no input is given, we throw exceptoin for PlateauUpperRightCoordinates

  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String emptyInput = "-5 0\n1 2 N\nML\n";

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Plateau upper right coordinates cannot be negative.");

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(emptyInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }
 }


 @Test
 public void initializeRoversShouldThrowIllegalArgumentsExceptionIfStartPositionIsEmpty() {
  // As they are the first ones in the input as of now,
  // if no input is given, we throw exceptoin for PlateauUpperRightCoordinates

  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String emptyInput = "5 0\n\nML\n";

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Input cannot be an empty.");

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(emptyInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }
 }

 @Test
 public void initializeRoversShouldThrowIllegalArgumentsExceptionIfInstructionsAreEmpty() {
  // As they are the first ones in the input as of now,
  // if no input is given, we throw exceptoin for PlateauUpperRightCoordinates

  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String emptyInput = "5 0\n1 2 E\n\n";

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Input cannot be an empty.");

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(emptyInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }
 }

 @Test
 public void initializeRoversShouldThrowIllegalArgumentsExceptionIfStartPositionHasNegativeCoordinates() {
  // As they are the first ones in the input as of now,
  // if no input is given, we throw exceptoin for PlateauUpperRightCoordinates

  ArrayList < Rover > rovers = new ArrayList < Rover > ();
  InitializeRovers init = new InitializeRovers();

  String emptyInput = "5 0\n-1 2 E\n\n";

  thrown.expect(IllegalArgumentException.class);
  thrown.expectMessage("Rover position coordinates cannot be negative.");

  InputStream stdin = System.in;
  try {
   System.setIn(new ByteArrayInputStream(emptyInput.getBytes()));
   Scanner sc = new Scanner(System.in);
   rovers = init.readRoversInput(sc);
   sc.close();
  } finally {
   System.setIn(stdin);
  }
 }

}