Design assumptions:
   . Coordinates are only positive integers. Coordinate values less than zero result in IllegalArgumentException.
   . Input is read from stdin, or optionally via a file sent from first commandline argument.
   . Rovers input is read completely, and then the actual nagivation starts.
   . Illegal input  that result in rover heading beyond the plateau boundary results in IllegalArgumentException.

Setting up:
   . These instructions are to run the program on Linux, or Linux like environment.
   . Go to any dirctory on a Linux machine, and copy the directory MarsRover_submission_VenkatakrishnaRaoKS
      which is archived in the file MarsRover_submission_VenkatakrishnaRaoKS.zip
   . UPDATE THE FILE: marsrover.env
   . Update the path to JAVA 8, and GRADLE_HOME in the env file marsrover.env
   . If GRADLE is NOT installed on your host, then, leave it blank, and the script will download it as necessary.
   . JAVA_HOME should be set to JAVA 8 installation directory ONLY!
   . Build and test writes files, and runs from the directory where this application is downloaded to,
     hence this directory should be writable for the user who runs the script.

How to run the application:
   . When marsrover.env is updated as instructed, Run, "sh marsrover.run"
   . This compiles the appliation, and runs the JUnit test cases, and reports the outcome.
   . If you would like to test the program with an input of your own, use the command 
     that this script prints in the end, to provide your input to the program from stdin.
   . OR modify the file marsRover.input to reflect your input to the program,
     and run this script again.
  

Thank you!
Venkat.
